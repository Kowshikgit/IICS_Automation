#!/usr/bin/python3

import requests as requests
import sys as sys

# reading request arguments
region=sys.argv[1]
userName=sys.argv[2]
Password=sys.argv[3]
Location=sys.argv[4]
old_prefix=sys.argv[5]
new_prefix=sys.argv[6]


Login_URL='https://{0}.informaticacloud.com/ma/api/v2/user/login'.format(region)
body= {"username":userName,"password":Password}

login=''

#login into IICS
try: 
    login=requests.post(Login_URL,json=body)

except:
    sys.exit('Provide a valid Cloud Region')


if login.status_code==200:

    login_json=login.json()
        
    icSessionId=login_json['icSessionId']
    Service_url=login_json['serverUrl']


    post_url=Service_url+'/public/core/v3/objects?q=type==MTT and location=={0}'.format(Location)

    Headers={'Content-Type':'application/json',
    'Accept': 'application/json',
    'INFA-SESSION-ID':icSessionId,
    'icSessionId':icSessionId}

    #pulling Assets based on query
    Query=requests.get(url=post_url,headers=Headers)
    Query_json=Query.json()

    if Query.status_code==200:

        id_list=[]
        name_list=[]
    

        for i in Query_json['objects']:
            id_list.append(i['id'])

            path=i["path"]

            pos = path.rfind('/')
            name = path[pos+1:]       
            name_list.append(name)

        for id,name in zip(id_list,name_list):
            get_meta=requests.get(url=Service_url+'/api/v2/mttask/frs/'+id,headers=Headers)
            id_meta=get_meta.json()

            if get_meta.status_code==200 :
                if id_meta["name"][0:len(old_prefix)].upper()==old_prefix.upper():
                    asset_name=id_meta["name"]
                    new_name=new_prefix+asset_name[len(old_prefix):len(asset_name)]
                    id_meta["name"]=new_name

                    desc=id_meta["description"]
                    if asset_name in desc:
                        id_meta["description"]=desc.replace(asset_name,new_name)

                    url_update=Service_url+'/api/v2/mttask/frs/'+id
                    #Headers["Update-Mode"]='Partial'
                    updating=requests.post(url=url_update,headers=Headers,json=id_meta)
                    if updating.status_code==200:
                        print('Mapping Task - {0} is renamed to {1}'.format(asset_name,new_name))  
                else:
                    print('MappingTask - {0} already renamed or MappingTask doesnt have Prefix'.format(id_meta["name"]))  
            else:
                print("Unable to fetch metadata for MCT -  {0}".format(name))    
    else:
        sys.exit("Location is Incorrect")            

else:
    sys.exit("Username/Password is Incorrect for the region : {0}".format(region))
                            