#####################################################################
This Script is used to rename Mapping Task prefix as per requirements.
It will rename Mappingtask name at Description also
#####################################################################

Syntax:

python path/rename.py cloudRegion IICS_username IICS_password Project/Folder old_prefix new)_prefix > path/outputfile

Sample Command:

"python /home/cloud_wf/data/Scripts/Kowshik/rename.py dm-us Kowshik_WF Dummy_pass github_check/folder_call s_ MCT_ > /home/cloud_wf/data/Scripts/Kowshik/out_rename.txt"


Argument1 - Region - Pass the cloud region where organization resides.found in IICS Login URL

Argument2 - Username - Username to login IICS account

Argument3 - password - password to login IICS account

Argument4 - location - location of the MCT. Format Project/Folder

Argument5 - old_prefix - string user wants to change in the MCT name [include underscore to avoid conflicts in name]

Argument6 - new_prefix - string user wants to replace in the MCT name [include underscore to avoid conflicts in name]

